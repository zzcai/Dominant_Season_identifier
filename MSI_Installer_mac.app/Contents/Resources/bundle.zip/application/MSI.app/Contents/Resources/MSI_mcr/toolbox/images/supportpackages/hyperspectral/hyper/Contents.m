% Image Processing Toolbox Hyperspectral Imaging Library
%
